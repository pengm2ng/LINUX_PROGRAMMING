#include <stdio.h>
#include <stdlib.h>

int main(){

system("./fcfs");
system("./rr");
system("./hrn");
}